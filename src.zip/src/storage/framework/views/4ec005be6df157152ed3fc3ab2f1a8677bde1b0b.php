<?php $__env->startSection('content'); ?>

<div class="login-box">
<!-- <div class="container"> -->
    <!-- <div class="row justify-content-center"> -->
        <!-- <div class="col-md-8"> -->
            <div class="login-logo">
                <img src="<?php echo e(asset('img/mot_01.gif')); ?>" alt="ロゴ">
                <p><b>会員登録</b></p>
            </div>

            <div class="card">
                <!-- <div class="card-header"><?php echo e(__('会員登録')); ?></div> -->

                <div class="card-body login-card-body">

                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <!-- 名前 -->
                        <div class="input-group mb-3">
                            <!-- <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('名前')); ?></label> -->
                            <!-- <div class="col-md-8"> -->
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus placeholder="名前を入力">
                                
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                    <span class="fas fa-smile"></span>
                                    </div>
                                </div>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <!-- </div> -->
                        </div>

                        <!-- メールアドレス -->
                        <div class="input-group mb-3">
                            <!-- <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('メールアドレス')); ?></label> -->

                            <!-- <div class="col-md-8"> -->
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="メールアドレスを入力">

                                <div class="input-group-append">
                                    <div class="input-group-text">
                                    <span class="fas fa-envelope"></span>
                                    </div>
                                </div>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <!-- </div> -->
                        </div>

                        <!-- パスワード -->
                        <div class="input-group mb-3">
                            <!-- <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('パスワード')); ?></label> -->

                            <!-- <div class="col-md-8"> -->
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password" placeholder="パスワードを入力">

                                <div class="input-group-append">
                                    <div class="input-group-text">
                                    <span class="fas fa-lock"></span>
                                    </div>
                                </div>

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <!-- </div> -->
                        </div>

                        <!-- パスワード（確認用） -->
                        <div class="input-group mb-3">
                            <!-- <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('パスワード（確認用）')); ?></label> -->

                            <!-- <div class="col-md-8"> -->
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="パスワードを入力（確認用）">
                            <!-- </div> -->
                            
                            <div class="input-group-append">
                                <div class="input-group-text">
                                <span class="fas fa-lock"></span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- 登録ボタン -->
                        <div class="row signup-btn">
                            <div class="col-12">
                                <button type="submit" class="btn btn-outline-primary btn-block">
                                    <?php echo e(__('登録')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <!-- </div> -->
    <!-- </div> -->
<!-- </div> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TeamDevelopment\src\resources\views/auth/register.blade.php ENDPATH**/ ?>