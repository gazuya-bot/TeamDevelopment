function delete_alert(e) {
    var app = <?php echo json_encode($array); ?>;
}